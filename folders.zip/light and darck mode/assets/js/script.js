const Label = document.querySelector(".label")
const Circle = document.querySelector(".circle")

var color =1;

var Click = true

Label.addEventListener("click",()=>{
    color++
    Circle.classList.toggle("move");
    if (color%2==0) {
        document.body.style.background="black"
        uppdateStorage()
    }
    else{
        document.body.style.background="white"
        localStorage.clear()
    }


    
})



function uppdateStorage(){
    localStorage.setItem("mode",JSON.stringify(Click))
}


checkloacalstorage()

function checkloacalstorage(){

    if(JSON.parse(localStorage.getItem("mode"))){
        document.body.style.background="black"
        Circle.classList.add("move");
    }
    else{
         document.body.style.background="white"
         Circle.classList.remove("move");
    }
    // if(localStorage.getItem("mode") == true){
    //          document.body.background = "black"
    // }
    // else{
    //     document.body.background ="white"
    // }
  
    

    setTimeout(()=>{
        checkloacalstorage()
    },1000)
}