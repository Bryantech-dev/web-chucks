const Left = document.querySelector(".left");
const Right = document.querySelector(".right");
const Container = document.querySelector(".container");

uppdate()
function uppdate(){

Left.addEventListener("mouseenter",()=>{
    Container.classList.add("active-left")
})
Left.addEventListener("mouseleave",()=>{
    Container.classList.remove("active-left")
})
Right.addEventListener("mouseenter",()=>{
    Container.classList.add("active-right")
})
Right.addEventListener("mouseleave",()=>{
    Container.classList.remove("active-right")
})

setTimeout(()=>{
    uppdate()
},0)

}