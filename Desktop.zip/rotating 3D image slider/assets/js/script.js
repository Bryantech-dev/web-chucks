

const imageD = document.querySelector(".image-container");

const prev = document.querySelector("#btn1");
const nex = document.querySelector("#btn2");


/// img index varriable

let x=0;
let time;




prev.addEventListener("click",()=>{
    x+=45;

    /// removing autoslide when butto clicked

    clearTimeout(time);

    ///updating img gallery
    updating();
})
nex.addEventListener("click",()=>{
        x-=45;
        clearTimeout(time)
        ne()
})


updating()


function updating(){
    imageD.style.transform = ` perspective(1000px) rotateY(${x}deg)  `

    time = setTimeout(()=>{
       x+=45;
       updating()
    },1000)
}



function ne(){
        imageD.style.transform = ` perspective(1000px) rotateY(${x}deg)  `
        
}



