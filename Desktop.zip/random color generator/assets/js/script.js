



const container = document.getElementById("container")
loadMore()

function loadMore(){

for (let index = 0; index < 30; index++) {
   
    const colorEl = document.createElement("div")
    colorEl.classList.add("color-container")

    container.appendChild(colorEl)
}


}

function load(){
    generateColor()
}

randomColor()

function randomColor(){
    const char = "0123456789abcdef";
    const codelenght = 6;

    let color = ""

    for (let index = 0; index < codelenght; index++) {
        
        const randoms =Math.floor(Math.random()*char.length);

        color+=char.substring(randoms,randoms+1);
        // setTimeout(()=>{
        //     randomColor()
        // },1000)

       
        
    }
    
    return color;
}

const colorContainer = document.querySelectorAll(".color-container");


generateColor()

function  generateColor(){
    colorContainer.forEach((colorContainer)=>{
          const newcolorcode = randomColor();

          colorContainer.style.background= "#"+newcolorcode;
          colorContainer.innerText = "#"+newcolorcode;
    })
}