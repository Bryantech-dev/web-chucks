

const teaxtarea = document.querySelector(".textarea");
const text = document.getElementById("text");
const tex = document.getElementById("rtext");

teaxtarea.addEventListener("keyup",()=>{
    update()
})

update()

function update(){
    text.innerText=teaxtarea.value.length;
    tex.innerText = teaxtarea.getAttribute("maxlength")-teaxtarea.value.length;
}